from flask import Flask, render_template, jsonify, send_from_directory, request, send_file
from PIL import ImageGrab, Image
from pdf2image import convert_from_path
from fpdf import FPDF
import io
import os
from subprocess import call
import time
import requests
from pydub import AudioSegment

app = Flask(__name__, static_folder='static')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start_screenshot', methods=['POST'])
def start_screenshot():
    try:

        pdf_path = os.path.join(app.static_folder, 'images', 'image.pdf')

        # Allow user to navigate to the window that should be screenshotted
        time.sleep(2)
        call(["/usr/sbin/screencapture", "-i", "-t" "pdf", pdf_path])
        
        # Convert the first page of the PDF to an image
        images = convert_from_path(pdf_path, first_page=1, last_page=1)
        image_path = os.path.join(app.static_folder, 'images', 'image.png')
        images[0].save(image_path, 'PNG')

        # Return a success response
        return jsonify({'status': 'Screenshot process started'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/upload_pdf', methods=['POST'])
def upload_pdf():
    
    if 'file' not in request.files:
        return jsonify({'status': False, 'message': 'No file part'})
    
    file = request.files['file']

    if file.filename == '':
        return jsonify({'status': False, 'message': 'No selected file'})
    
    pdf_path = os.path.join(app.static_folder, 'images', 'image.pdf')
    image_path = os.path.join(app.static_folder, 'images', 'image.png')

    # Save the uploaded PDF directly as 'image.png' in the static/images folder
    try:
        file.save(pdf_path)

        # Convert the first page of the PDF to PNG
        images = convert_from_path(pdf_path, first_page=1, last_page=1)
        images[0].save(image_path, 'PNG')
        return jsonify({'status': True, 'message': 'PDF uploaded successfully and saved as image.png.'})
    except Exception as e:
        return jsonify({'status': False, 'message': f'Error saving the PDF: {str(e)}'})

@app.route('/upload_audio', methods=['POST'])
def upload_audio():
    if 'audio' not in request.files:
        return jsonify({'status': 'error', 'message': 'No audio file uploaded'}), 400
    
    audio = request.files['audio']
    file_path = os.path.join(app.static_folder, 'speech-to-text', audio.filename)
    audio.save(file_path)

    # Convert the audio file to MP3 and save it
    try:
        audio_data = AudioSegment.from_file(file_path)
        mp3_filename = os.path.splitext(audio.filename)[0] + '.mp3'
        mp3_file_path = os.path.join(app.static_folder, 'speech-to-text', mp3_filename)
        audio_data.export(mp3_file_path, format="mp3")
    except Exception as e:
        print("Something didn't work")
        return jsonify({'status': 'error', 'message': f'Failed to convert to MP3: {str(e)}'}), 500

    # Trigger a GET request to http://localhost:8081/stt
    try:
        response = requests.get('http://localhost:8081/stt')
        
        # Check if the GET request was successful
        if response.status_code == 200:
            stt_result = response.json()  # Assuming the response is JSON
            print(stt_result)
            return jsonify({'status': 'success', 'stt_result': stt_result})
        else:
            return jsonify({'status': 'error', 'message': 'Failed to call STT service'}), response.status_code
    
    except requests.exceptions.RequestException as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# @app.route('/get_pdf')
# def get_pdf():
#     return send_from_directory(os.path.join(app.static_folder, 'images'), 'image.pdf')

if __name__ == '__main__':
    app.run(debug=True)